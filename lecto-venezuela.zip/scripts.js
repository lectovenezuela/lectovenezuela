function searchBooks() {
    var input, filter, bookList, books, title, i, txtValue;
    input = document.getElementById('searchInput');
    filter = input.value.toUpperCase();
    bookList = document.getElementsByClassName('book-list')[0];
    books = bookList.getElementsByClassName('book');
    for (i = 0; i < books.length; i++) {
        title = books[i].getElementsByTagName("h3")[0];
        txtValue = title.textContent || title.innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
            books[i].style.display = "";
        } else {
            books[i].style.display = "none";
        }
    }
}